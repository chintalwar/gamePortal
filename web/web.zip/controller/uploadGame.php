<?php

        include "controller/config.php";

        if(isset($_POST['submit'])){
            
            $id              = $_POST['id'];
            $gameName        = $_POST['gameName'];
	        $gameCategory    = $_POST['gameCategory'];
            $gameLogo        = $_FILES['photo'];
            $gameFile        = $_FILES['file'];

            //fetch the file name
            $fileName = $gameFile['name'];
                         
            //fetch the defualt file path  
            $filePath = $gameFile['tmp_name'];
      
            //fetch the file error if 
            $fileError = $gameFile['error'];

             //fetch the file name
             $logoName = $gameLogo['name'];

             //fetch logo path
             $logoPath = $gameLogo['tmp_name'];   
        

            if($fileError == 0){
                 
                $fileDestination = 'upload/'.$fileName;
            //    echo "$fileDestination";

                //to upload at desire destination we have thew function
                //it takes 2 parameter temprory file path and destianation file path

                move_uploaded_file($filePath,$fileDestination);

                //insert query
                if($id==""){
                $insert = "INSERT INTO `game_master`(name,category,logo,folder)
                           VALUES ('$gameName',' $gameCategory','$logoName','$fileDestination')";
                }else{
                    $insert = "UPDATE `game_master` SET  name='$gameName',category='$gameCategory',logo='$logoName',folder='$fileDestination' WHERE id=$id";
                }
                           $query = mysqli_query($con,$insert);
                           if($query){

                            ?>
                            <script>
                            //    alert(" UPLOAD SUCCESSFULLY :)");
                               location.replace("admin.php");
                            </script>
                            <?php
                           }else{
                            ?>
                            <script>
                               alert(" UPLOAD ERROR:)");
                               location.replace("admin.php");
                            </script>
                            <?php
                           }
            }
            
        }
?>