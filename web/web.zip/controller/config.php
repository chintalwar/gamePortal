<?php

$servername  = "localhost";
$username    = "root";
$passwor     = "";
$db_name     = "game_portal";

$con = mysqli_connect($servername,$username,$passwor,$db_name);

// if($con){
//     
//           alert("Connected");
//       </script>
//     <?php
// }else{
//     
//           alert("not Connected");
//       </script>
//     <?php
// }

?>
