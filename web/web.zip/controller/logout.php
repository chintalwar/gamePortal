<?php

   session_start();
   session_destroy();
   ?>
   <script>
   location.replace("../pages/signlog.php");
   </script>
   <?php
?>